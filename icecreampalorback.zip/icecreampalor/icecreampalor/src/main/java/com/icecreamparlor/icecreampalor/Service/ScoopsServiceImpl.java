package com.icecreamparlor.icecreampalor.Service;

import java.util.*;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icecreamparlor.icecreampalor.Entity.Scoops;
import com.icecreamparlor.icecreampalor.Repository.ScoopsRepo;

import lombok.extern.slf4j.Slf4j;

@Service
public class ScoopsServiceImpl implements ScoopsService{

	@Autowired
	private ScoopsRepo scoopsrepo;
	
	@Override
	public Scoops saveScoops(Scoops scoops) {
		System.out.println("scoops: "+scoops);
		// TODO Auto-generated method stub
		return scoopsrepo.save(scoops) ;
	}
	@Override
	public Scoops getScoops(int id) {
		Optional<Scoops> scoopsFromDB = scoopsrepo.findById(id);
		return scoopsFromDB.orElse(null);
		
	}
	@Override
	public List<Scoops> getScoops()
	{
		return scoopsrepo.findAll();
	}
	@Override
	public String deleteScoops(int id) {
		
		
			scoopsrepo.deleteById(id);
			return "Deleted";
				 
	}
	@Override
	public Scoops updateScoops(Scoops scoops) {
		// TODO Auto-generated method stub
		return scoopsrepo.save(scoops) ;
	}
	
	
}
