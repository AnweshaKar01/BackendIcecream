package com.icecreamparlor.icecreampalor.Entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity 
// this tells spring boot that this particular class belongs to the entity in mysql db 
// will automatically generate the getters and setters
@Data
@Table(name = "Scoops_DB")
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Scoops {
	// @Column(name="iceId") //give name to this column
	// tells that this particular variable is the id
	@Id 
	// generate automated values
	@GeneratedValue(strategy = GenerationType.AUTO) 
	private Integer scoopsId;

	private String title;

	private double price;

	@Column(name = "AmountLeft")
	private double amount;
}
