package com.icecreamparlor.icecreampalor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IcecreampalorApplicationTests {

	@Test
	void contextLoads() {
	}

}
