package com.cart.cart.cartController;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cart.cart.cartEntity.Cart;
import com.cart.cart.cartService.CartServiceImpl;



@RestController
public class CartController {
	
	private CartServiceImpl cartServiceImpl;
	
	@PostMapping("/addCartItem")
	public Cart postDetails(@RequestBody Cart cart) {
		return cartServiceImpl.saveCart(cart);

	}
}
