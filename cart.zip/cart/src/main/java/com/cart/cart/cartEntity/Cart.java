package com.cart.cart.cartEntity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="Cart_DB")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Cart {
		@Id
		@GeneratedValue(strategy= GenerationType.AUTO )
		private int cartId;
		
		private String item;
		
		private double  item_amount;
		
		private double item_price;
		
}
