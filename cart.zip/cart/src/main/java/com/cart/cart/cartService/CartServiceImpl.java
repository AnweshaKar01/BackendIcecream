package com.cart.cart.cartService;

import org.springframework.beans.factory.annotation.Autowired;

import com.cart.cart.cartEntity.Cart;
import com.cart.cart.cartRepository.CartRepo;

public class CartServiceImpl  implements CartService{
	@Autowired
	private CartRepo cartRepo;
	
	@Override
	public Cart saveCart(Cart cart) {
		// TODO Auto-generated method stub
		return cartRepo.save(cart);
	}

	
	
	

}
