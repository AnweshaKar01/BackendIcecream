package com.cart.cart.cartService;

import com.cart.cart.cartEntity.Cart;

public interface CartService {
	public Cart saveCart();
}
