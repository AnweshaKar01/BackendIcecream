package com.cart.cart.cartRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cart.cart.cartEntity.Cart;

public interface CartRepo  extends JpaRepository<Cart, Integer>{

	
}
